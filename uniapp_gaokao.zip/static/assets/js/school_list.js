$(document).ready(function () {
    load_list()
    if (!window.location.search.substring(5).includes("predict")) {
        load_page_selector()
    }
});

function load_page_selector() {
    let page = getV("page")
    let str = ""
    let pre_url = ""
    if (page != null) {
        pre_url = window.location.search.substring(5).replace(/page=(\d+)/g, "page=" + Number(page - 1))
        str += "        <li class=\"page-item\" id=\"left-arrow\">\n" +
            "            <a class=\"page-link\" href=\"/page/school_list?url=" + pre_url + "\">\n" +
            "             <span class=\"fa fa-chevron-left\"></span>\n" +
            "            </a>\n" +
            "           </li>\n"
    } else {
        page = 1
    }
    let page_next = Number(page) + 1
    let next_url = window.location.search.substring(5).replace(/page=(\d+)/g, "page=" + page_next)
    if (page == 1 && next_url.includes("?")) {
        next_url += "&page=" + (page + 1)
    } else if (page == 1) {
        next_url += "?page=" + (page + 1)
    }
    str +=
        "           <li class=\"page-item active\"><a class=\"page-link\">" + Number(page) + "</a></li>\n" +
        "           <li class=\"page-item\" id=\"right-arrow\">\n" +
        "            <a class=\"page-link\" href=\"/page/school_list?url=" + next_url + "\" >\n" +
        "             <span class=\"fa fa-chevron-right\"></span>\n" +
        "            </a>\n" +
        "           </li>"
    $("#page-select").html(str)
}


function load_list() {

    $.ajax({
        type: "get",
        url: window.location.search.substring(5),
        async: true,
        dataType: "json",
        success: function (data) {
            let str = ""
            if (data.code == 1) {
                let list = data.data
                for (let i in list) {
                    str += "<div class=\"product-list-view row\" style='height: 250px;overflow: hidden;'>\n" +
                        "    <div class=\"col-12 pt-6\">\n" +
                        "        <div class=\"product-item\">\n" +
                        "            <div class=\"product-img\">\n" +
                        "                <a href=\"/page/college_info?url=/college/info?cid=" + list[i].cid + "\">\n" +
                        "                    <img style='width: 200px;height: 200px' src=\"https://static-data.gaokao.cn/upload/logo/" + list[i].cid + ".jpg\"\n" +
                        "                        \">\n" +
                        "                </a>\n" +
                        "            </div>\n" +
                        "            <div class=\"product-content align-self-center\">\n" +
                        "                <a class=\"product-name pb-2\" href=\"/page/college_info?url=/college/info?cid=" + list[i].cid + "\">" + list[i].name + "</a>\n" +
                        "                <div>\n" +
                        "                    <div style=\"display: inline;margin-right: 20px\">" + list[i].city_name + "</div>\n" +
                        "                    <div style='display: inline'>" + list[i].type_name + "</div>\n" +
                        "                </div>\n" +
                        "\n"
                    if (list[i].introduction != null) {
                        str += "                <p class=\"short-desc mb-0\">" + list[i].introduction.substring(0, 200).trim() + "······" + "</p>\n"
                    }
                    str +=
                        "            </div>\n" +
                        "        </div>\n" +
                        "    </div>\n" +
                        "</div>"
                }
            } else {
                alert(data.message)
                window.history.back()
            }
            $("#list-view").html(str)
        },
        error: function () {
            console.log("error");
        }
    });
}

function getV(variable) {
    let result = window.location.search.substring(5);
    if (variable != null) {
        result = getQueryVariable(result, variable)
    }
    return result;
}

function getQueryVariable(str, variable) {
    if (str.split("?").length == 1) {
        return null
    }
    var query = str.split("?")[1]
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
            return decodeURI(pair[1]);
        }
    }
    return null;
}
