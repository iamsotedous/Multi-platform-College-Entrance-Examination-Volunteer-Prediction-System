$(document).ready(function () {
    batch_change()
});

function province_change() {
    batch_change()
}

function batch_change() {
    let pid = $("#province-select").val()
    $.ajax({
        type: "get",
        url: "/record/batch?pid=" + pid,
        async: true,
        dataType: "json",
        success: function (data) {
            let batches = data.data
            let str = ""
            for (let i in batches) {
                str += "<option value=\"" + batches[i].rbatch + "\" style=\"text-align: center\">" + batches[i].rbatch + "</option>"
            }
            $("#batch-select").html(str)
            require_change()
        },
        error: function () {
            console.log("error");
        }
    });
}

function require_change() {
    let pid = $("#province-select").val()
    let batch = $("#batch-select").val()
    $.ajax({
        type: "get",
        url: "/record/require?pid=" + pid + "&batch=" + batch,
        async: true,
        dataType: "json",
        success: function (data) {
            let requires = data.data
            let str = ""
            for (let i in requires) {
                str += "<option value=\"" + requires[i].mrequire + "\" style=\"text-align: center\">" + requires[i].mrequire + "</option>"
            }
            $("#require-select").html(str)
        },
        error: function () {
            console.log("error");
        }
    });
}

function choose() {
    let pid = $("#province-select").val()
    let batch = $("#batch-select").val()
    let require = $("#require-select").val()
    let rank = $("#search-rank").val()
    if (isNaN(rank) || rank <= 0 || rank >= 500000) {
        alert("非法排名")
        return
    }
    window.location.href = "/page/school_list?url=/college/predict?pid=" + pid + "&batch=" + batch + "&mrequire=" + require + "&rank=" + rank
}