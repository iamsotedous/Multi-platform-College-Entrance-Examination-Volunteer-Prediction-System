<template>
  <view class="main-wrapper">
    <!-- 顶部栏 -->
    <view class="main-header_area">
      <view class="header-middle container d-flex align-items-center justify-content-between py-2">
        <!-- logo -->
        <navigator url="/page/index" class="header-logo mr-3">
          <image src="/static/assets/images/logo/logo.png" alt="Header Logo" style="width: 200rpx; height: 80rpx;"></image>
        </navigator>
        <!-- 大学选择框和搜索框在同一行 -->
        <view class="search-and-select d-flex align-items-center flex-grow-1">
          <!-- 下拉框 -->
          <picker mode="selector" range="{1}" @change="selectOption" class="mr-2">
            <view class="nice-select select-option">
              <text>{{ selectedOption }}</text>
            </view>
          </picker>
  		  <view class="separator"></view> <!-- 添加分隔 -->
          <!-- 搜索框 -->
          <form class="header-searchbox d-flex align-items-center" @submit.stop>
            <input v-model="searchTerm" class="input-field" type="text" :placeholder="searchPlaceholder" />
            <button class="search-button" type="button" @click="search">
              <i class="pe-7s-search"></i>
            </button>
          </form>
        </view>
        <!-- 用户菜单入口 -->
        <view class="header-right">
          <button v-if="loggedIn" class="user-menu" type="button" id="accountButton">
            <text>本人账号</text>
          </button>
          <button v-if="loggedIn" class="user-menu" type="button" id="favoritesButton">
            <text>我的收藏</text>
          </button>
          <button v-if="loggedIn" class="user-menu" type="button" id="logoutButton" @click="logout">
            <text>退出</text>
          </button>
          <button v-if="!loggedIn" class="user-menu" type="button" id="loginButton" @click="showLoginRegisterPage">
            <text>登陆/注册</text>
          </button>
        </view>
      </view>
    </view>
    <!-- 功能栏 -->
    <view class="main-menu d-flex justify-content-center align-items-center bg-light py-1" style="background-color: cadetblue;">
          <navigator url="/page/school_list?url=/college/985" @click="selectCategory('985')">985</navigator>
      <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
      <navigator url="/page/school_list?url=/college/211">211</navigator>
      <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
      <navigator url="/page/school_list?url=/college/doubleGood">双一流</navigator>
      <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
      <navigator url="/page/choose">筛选</navigator>
    </view>
	
	
    <!-- 填充区 -->
    <view class="main-content">
      <view class="breadcrumb-area breadcrumb-height" data-bg-image="/static/assets/images/register-login.png">
          <view class="container h-100 position-relative"> <!-- 添加 position-relative 类 -->
            <view class="row h-100">
              <view class="col-lg-12">
                <view class="breadcrumb-item position-absolute top-50 start-50 translate-middle"> <!-- 添加 position-absolute 和相应的 Bootstrap 类 -->
                  <text class="breadcrumb-heading" style="font-size: 30px;">高考志愿网</text> <!-- 修改字体大小 -->
                  <view class="d-flex align-items-center">
                    <navigator url="/page/index">首页<text class="pe-7s-angle-right"></text></navigator>
                    <text>院校列表</text>
                  </view>
                </view>
              </view>
            </view>
          </view>
        </view>
      <view class="shop-area section-space-y-axis-100">
        <view class="container">
          <view class="row">
            <view class="col-lg-12">
              <view class="product-topbar">
                <ul>
                  <li style="width: 100%;text-align: center">搜索结果</li>
                </ul>
              </view>
              <view class="tab-content pt-8">
                <view class="tab-pane fade show active" id="list-view" role="tabpanel" aria-labelledby="list-view-tab">
                  <!-- 列表内容 -->
                </view>
              </view>
              <view class="pagination-area pt-10">
                <navigator url="/page/select">
                  <view class="pagination justify-content-center" id="page-select">
                    <!-- 分页内容 -->
                  </view>
                </navigator>
              </view>
            </view>
          </view>
        </view>
      </view>
    </view>
	
	
	<!-- 大学简介 -->
	    <div class="university-intro-section">
	        <div class="container">
	          <div class="row">
	            <div class="col-lg-4" v-for="university in filteredUniversities" :key="university.id">
	              <div class="university-card">
	                <div class="card-content">
	                  <!-- University Logo -->
	                  <img :src="university.logo" alt="University Logo" class="university-logo">
	                  <div class="university-info">
	                    <!-- University Name -->
	                    <h3>{{ university.name }}</h3>
	                    <!-- University Location and Category -->
	                    <p>{{ university.location }}, {{ university.category }}</p>
	                    <!-- University Introduction -->
	                    <p>{{ university.introduction }}</p>
	                  </div>
	                </div>
	              </div>
	            </div>
	          </div>
	        </div>
	      </div>

	
	<!-- 底部栏 -->
    <view class="footer-area" style="margin-top: 10px">
      <view class="footer-bottom py-3" :style="{ 'background-color': bgColour }">
        <view class="container">
          <view class="row">
            <view class="col-lg-12">
              <view class="copyright">
                <text class="copyright-text text-white">Made By NPU</text>
              </view>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      loggedIn: false,
      selectOptions: ['大学', '专业'], // 下拉框选项
      selectedOption: '大学', // 默认选择
      searchTerm: '',
	  
	  selectedCategory: null, // 存储当前选择的院校类型
	  universities: [
    {
        "id": 1,
        "name": "清华大学",
        "logo": "/static/assets/images/universities/qinghua.png",
        "location": "北京",
        "category": "985",
        "introduction": "清华大学，简称“清华”，位于中国北京市海淀区，是中华人民共和国教育部直属，由教育部、国家发展改革委员会和北京市共建，是中国乃至世界顶尖的综合性研究型大学之一。"
    },
    {
        "id": 2,
        "name": "北京大学",
        "logo": "/static/assets/images/universities/beida.png",
        "location": "北京",
        "category": "985",
        "introduction": "北京大学，简称“北大”，位于中华人民共和国北京市海淀区，创建于1898年，是中国近代最早建立的高等学府之一，是新文化运动的发祥地，是国家“985工程”和“211工程”重点支持的世界一流大学。"
    },
    {
        "id": 3,
        "name": "上海交通大学",
        "logo": "/static/assets/images/universities/sjtu.png",
        "location": "上海",
        "category": "综合",
        "introduction": "上海交通大学，简称“交大”，坐落于中国上海市徐汇区，是中国教育部直属的全日制普通高等学校，是中华人民共和国国家“双一流”、“211工程”、“985工程”重点建设的高水平大学。"
    },
    {
        "id": 4,
        "name": "复旦大学",
        "logo": "/static/assets/images/universities/fudan.png",
        "location": "上海",
        "category": "综合",
        "introduction": "复旦大学，位于中国上海市杨浦区，前身是1905年创建于上海的复旦公学，是中国人民共和国教育部直属，入选国家“双一流”、“985工程”、“211工程”、“2011计划”和“111计划”等国家重点建设的高水平大学。"
    },
    {
        "id": 5,
        "name": "浙江大学",
        "logo": "/static/assets/images/universities/zhejiang.png",
        "location": "杭州",
        "category": "综合",
        "introduction": "浙江大学，简称“浙大”，位于中国浙江省杭州市西湖区，创建于1897年，是中国最早的现代高等学府之一，是国家“双一流”、“985工程”、“211工程”、“2011计划”重点建设的世界一流大学。"
    },
    {
        "id": 6,
        "name": "中国科学技术大学",
        "logo": "/static/assets/images/universities/ustc.png",
        "location": "合肥",
        "category": "工科",
        "introduction": "中国科学技术大学，简称“中科大”，位于安徽省合肥市，是中国科学院所属的一所以前沿科学和高新技术为主、兼有特色管理与人文学科的综合性全国重点大学。"
    },
    {
        "id": 7,
        "name": "南京大学",
        "logo": "/static/assets/images/universities/nanjing-1.png",
        "location": "南京",
        "category": "综合",
        "introduction": "南京大学，简称“南大”，位于江苏省南京市，创建于1902年，是中国最早的现代高等学府之一，入选国家“双一流”、“985工程”、“211工程”、“2011计划”重点建设的世界一流大学。"
    },
    {
        "id": 8,
        "name": "哈尔滨工业大学",
        "logo": "/static/assets/images/universities/hit-1.png",
        "location": "哈尔滨",
        "category": "工科",
        "introduction": "哈尔滨工业大学，简称“哈工大”，位于中国黑龙江省哈尔滨市南岗区，创建于1920年，是中国最早的工科高等学府之一，是国家“双一流”、“985工程”、“211工程”重点建设的世界一流大学。"
    },
    {
        "id": 9,
        "name": "西安交通大学",
        "logo": "/static/assets/images/universities/xjtu.png",
        "location": "西安",
        "category": "工科",
        "introduction": "西安交通大学，简称“西交大”，位于陕西省西安市雁塔区，创建于1896年，是中国最早的工科高等学府之一，是国家“双一流”、“985工程”、“211工程”重点建设的世界一流大学。"
    },
    {
        "id": 10,
        "name": "西北工业大学",
        "logo": "/static/assets/images/universities/nwpu.png",
        "location": "西安",
        "category": "工科",
        "introduction": "西北工业大学，简称“西工大”，位于陕西省西安市长安区，创建于1938年，是中国最早的工科高等学府之一，是国家“双一流”、“985工程”、“211工程”重点建设的世界一流大学。"
    }
],
    };
  },
  computed: {
      // 根据 selectedCategory 进行动态筛选大学信息
      filteredUniversities() {
        if (!this.selectedCategory) {
          return this.universities; // 如果未选择分类，则显示所有大学信息
        }
        return this.universities.filter(university => university.category === this.selectedCategory);
      },
    },
    mounted() {
      // 在组件挂载后加载JSON数据
      this.loadUniversitiesData();
    },
  methods: {
	/*  // 加载JSON文件数据
    loadUniversitiesData() {
      fetch('/static/js/school_list.json')
        .then(response => response.json())
        .then(data => {
          // 加载成功，保存数据到组件的data中
          this.universities = data;
        })
        .catch(error => {
          console.error('Error loading universities data:', error);
        });
    },*/
	selectOption(event) {
	  this.selectedOption = this.selectOptions[event.detail.value];
	  this.searchPlaceholder = this.selectedOption === '大学' ? '输入大学关键字' : '输入专业关键字';
	},
	
    toggleUserMenu() {
      this.showUserMenu = !this.showUserMenu
    },
    selectSearchType(e) {
      this.searchTypeIndex = e.detail.value
    },
    search() {
      // 执行搜索逻辑
    },
	selectCategory(category) {
	  console.log('Selected category:', category); // 检查参数是否正确
	  this.selectedCategory = category;
	  console.log('Updated selected category:', this.selectedCategory); // 检查更新后的值是否正确
	  // 如果需要在点击后立即更新大学简介部分，可以手动触发计算属性
	  this.filteredUniversities;
	},
  }
}
</script>

<style scoped>
/* 样式表 */
/* 将顶部栏设置为flex布局 */
.header-middle {
  display: flex;
  align-items: center;
  justify-content: space-between; /* 使子元素均匀分布 */
  padding: 0 1rem; /* 调整内边距 */
}

.header-right {
  display: flex;
  align-items: center;
  justify-content: flex-end; /* 将内容推到最右侧 */
}

/* 下拉框和搜索框之间的分隔样式 */
.separator {
  width: 30rpx; /* 设置分隔宽度 */
}

.select-option text {
  color: #333; /* 设置文字颜色 */
}

/* 下拉框样式 */
.select-option {
  background-color:skyblue; /* 设置背景色 */
  padding: 8rpx 12rpx; /* 设置内边距 */
  border-radius: 5rpx; /* 设置圆角 */
}

/* 调整搜索框区域的样式，使其占据剩余空间 */
.search-and-select {
  flex-grow: 0; /* 使搜索框区域填充剩余空间 */
  display: flex;
  align-items: center;
}

/* 搜索框样式调整 */
.header-searchbox input {
  padding: 12rpx; /* 增加填充以使搜索框更高 */
  width: 300rpx; /* 增加宽度 */
  border: 1rpx solid #ddd; /* 添加边框样式 */
}

/* 为985、211、双一流导航按钮添加样式 */
.main-menu {
  display: flex;
  justify-content: center; /* 水平居中对齐 */
  align-items: center; /* 垂直居中对齐 */
  height: 40px; /* 设置容器的高度 */
}

/* 添加一个分隔符样式，用于在项目之间创建间距 */
.menu-separator {
  width: 60rpx; /* 设置分隔符的宽度 */
}
  
/*填充区*/
.breadcrumb-area {
  width:100%; /* 设置宽度为100%，使其充满父容器 */
  height: 500px; /* 设置高度为300像素，或者你想要的其他大小 */
  background-image: url("/static/assets/images/register-login.png");
  background-size:  auto;
  background-position: center center; /* 将背景图像水平和垂直居中 */
  background-repeat: no-repeat; /* 禁止背景图像重复 */
}

.position-relative {
  position: relative; /* 设置相对定位 */
}

.position-absolute {
  position: absolute; /* 设置绝对定位 */
}

.top-50 {
  top: 50%; /* 将元素的顶部边缘放置在其包含元素的顶部边缘的50%处 */
}

.start-50 {
  start: 50%; /* 将元素的左边缘放置在其包含元素的左边缘的50%处 */
}

.translate-middle {
  transform: translate(460%, 200%); /* 平移元素的中心点到其包含元素的中心点 */
}

/*大学介绍*/
.university-card {
  margin-bottom: 20px; /* 添加底部间距 */
  padding: 20px;
  border: 1px solid #ccc; /* 添加边框 */
  border-radius: 5px; /* 添加圆角 */
  background-color: #f9f9f9; /* 设置背景色 */
  width: 60%; /* 自动调整宽度 */
  margin: 20px auto;
  display: flex; /* 使用flex布局 */
  align-items: flex-start; /* 顶部对齐 */
}

.card-content {
  display: flex; /* 使用flex布局 */
  align-items: flex-start; /* 顶部对齐 */
}

.university-logo {
    width: 400px; /* 调整校徽图片的宽度 */
    height: 200px; /* 高度自动调整 */
    margin-right: 30px;
	object-fit: contain;
}

.university-info {
  flex-grow: 1; /* 让文字介绍部分填充剩余空间 */  
  margin-left: calc(30% - 230px); 
}

.university-card h3 {
  margin-top: 0; /* 移除顶部间距 */
  font-size: 28px; /* 设置标题字体大小 */
}

.university-card p {
  margin-bottom: 15px !important;/*正文与位置之间距离*/
  font-size: 18px; /* 设置标题字体大小 */
}

.university-intro-section {
  padding: 20px 0; /* 添加内边距 */
}

.university-card img {
  display: block; /* 确保图片占据整个空间 */
  margin: 0 auto 10px; /* 居中并添加底部间距 */
}


</style>
