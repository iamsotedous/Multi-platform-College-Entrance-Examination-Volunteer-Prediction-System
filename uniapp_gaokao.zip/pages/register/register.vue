<!-- register.vue -->
<template>
	<view id="login_header">
	  <navigator url="../../index.html">
	    <image class="logo_img" :src="'/static/assets/images/logo/logo.png'" mode="aspectFit" style="width: 200px; height: 75px;" />
	  </navigator>
	</view>
  <!-- 注册页面模板 -->
  <view>
    <!-- 注册表单区域 -->
    <view class="login_banner">
      <view class="register_form">
        <h1>用户注册</h1>
        <form @submit="registersubmit">
          <!-- 用户名输入框 -->
          <div class="form-item">
            <div>
              <label>用户名称:</label>
              <input type="text" placeholder="请输入用户名称" name="userName" v-model="uname" @blur="checkname" />
            </div>
            <span class="errMess">{{ uname_errmess }}</span>
          </div>
          <!-- 密码输入框 -->
          <div class="form-item">
            <div>
              <label>用户密码:</label>
              <input type="password" placeholder="请输入密码" name="passWord" v-model="upass" @blur="checkupass" />
            </div>
            <span class="errMess">{{ upass_errmess }}</span>
          </div>
          <!-- 确认密码输入框 -->
          <div class="form-item">
            <div>
              <label>确认密码:</label>
              <input type="password" placeholder="请输入确认密码" v-model="reupass" @blur="checkreupass" />
            </div>
            <span class="errMess">{{ reupass_errmess }}</span>
          </div>
          <!-- 用户邮箱输入框 -->
          <div class="form-item">
            <div>
              <label>用户邮箱:</label>
              <input type="text" placeholder="请输入邮箱" name="email" v-model="uemail" @blur="checkuemail" />
            </div>
            <span class="errMess">{{ uemail_errmess }}</span>
          </div>
          <!-- 验证码输入框 -->
          <div class="form-item">
            <div>
              <label>验证码:</label>
              <div class="verify">
                <input type="text" name="inputcoding" placeholder="" />
                <!-- 验证码图片 -->
                <image :src="changereq" @click="changepic" alt="" style="height: 40px; width: 150px;" />
              </div>
            </div>
            <span class="errMess">{{ errormessage }}</span>
          </div>
          <!-- 注册按钮 -->
          <button class="btn">注册</button>
        </form>
      </view>
    </view>
    <!-- 页面底部 -->
    <view class="bottom">
      <!-- 版权信息 -->
      <text>
        <navigator url="../../index.html">高考志愿网.Copyright ©2024</navigator>
      </text>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      uname: '', // 用户名
      upass: '', // 密码
      reupass: '', // 确认密码
      uemail: '', // 用户邮箱
      uname_errmess: '', // 用户名错误信息
      upass_errmess: '', // 密码错误信息
      reupass_errmess: '', // 确认密码错误信息
      uemail_errmess: '', // 邮箱错误信息
      changereq: '/books/getpig', // 验证码请求地址
      errormessage: '' // 错误信息
    };
  },
  methods: {
    registersubmit() {
      // 注册表单提交逻辑
    },
    // 其他注册相关方法需要根据原来的实现进行修改
  }
};
</script>

<style scoped>
/* 注册页面CSS样式 */
#login_header {
  height: 82px;
  width: 1200px;
}

.login_banner {
  height: 475px;
  background-color: rgb(0,84,163);
}

.login_form {
  height: 310px;
  width: 406px;
  float: right;
  margin-right: 50px;
  margin-top: 50px;
  background-color: #fff;
}

#content {
  height: 475px;
  width: 1200px;
}

.login_box {
  margin: 20px;
  height: 260px;
  /* width: 366px; */
}

.login_banner {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.login_banner .register_form {
  width: 506px;
  height: 450px;
  background-color: #fff;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.login_banner .register_form h1 {
  color: rgb(0, 84, 163);
  margin: 15px 0;
}

.login_banner .register_form form {
  width: 100%;
  height: 100%;
  font-size: 16px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.login_banner .register_form form .form-item {
  display: flex;
  width: 346px;
  flex-direction: column;
  margin: 0;
}

.login_banner .register_form form .form-item div {
  margin: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.login_banner .register_form form .form-item div input {
  width: 262px;
  height: 40px;
  border: 1px #e3e3e3 solid;
  outline: none;
}

.login_banner .register_form form .form-item .errMess {
  font-size: 12px;
  color: red;
  margin: 2px 0;
}

.login_banner .register_form form .form-item:nth-last-child(2) .verify {
  width: 264px;
}

.login_banner .register_form form .form-item:nth-last-child(2) .verify input {
  width: 146px;
}

.login_banner .register_form form .btn {
  width: 360px;
  height: 40px;
  background-color: rgb(0, 84, 163);
  color: #fff;
  outline: none;
  border: none;
  margin-top: 10px;
}

.bottom {
  text-align: center; /* 文本居中 */
  margin-top: 20px; /* 可以根据需要调整底部距离 */
}
</style>
