<template>
  <div class="college-info">
    <!-- 顶部栏 -->
    <div class="main-header_area">
      <!-- 顶部栏内容 -->
      <div class="header-middle container d-flex align-items-center justify-content-between py-2">
        <!-- logo -->
        <navigator url="/page/index" class="header-logo mr-3">
          <image src="/static/assets/images/logo/logo.png" alt="Header Logo" style="width: 200rpx; height: 80rpx;"></image>
        </navigator>
        <!-- 大学选择框和搜索框在同一行 -->
        <div class="search-and-select d-flex align-items-center flex-grow-1">
          <!-- 下拉框 -->
          <picker mode="selector" range="{1}" @change="selectOption" class="mr-2">
            <view class="nice-select select-option">
              <text>{{ selectedOption }}</text>
            </view>
          </picker>
          <div class="separator"></div> <!-- 添加分隔 -->
          <!-- 搜索框 -->
          <form class="header-searchbox d-flex align-items-center" @submit.stop>
            <input v-model="searchTerm" class="input-field" type="text" :placeholder="searchPlaceholder" />
            <button class="search-button" type="button" @click="search">
              <i class="pe-7s-search"></i>
            </button>
          </form>
        </div>
        <!-- 用户菜单入口 -->
        <div class="header-right">
          <button v-if="loggedIn" class="user-menu" type="button" id="accountButton">
            <text>本人账号</text>
          </button>
          <button v-if="loggedIn" class="user-menu" type="button" id="favoritesButton">
            <text>我的收藏</text>
          </button>
          <button v-if="loggedIn" class="user-menu" type="button" id="logoutButton" @click="logout">
            <text>退出</text>
          </button>
          <button v-if="!loggedIn" class="user-menu" type="button" id="loginButton" @click="showLoginRegisterPage">
            <text>登陆/注册</text>
          </button>
        </div>
      </div>
    </div>
	<!-- 功能栏 -->
	<view class="main-menu d-flex justify-content-center align-items-center bg-light py-1" style="background-color: cadetblue;">
	      <navigator url="/page/school_list?url=/college/985" @click="selectCategory('985')">985</navigator>
	  <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
	  <navigator url="/page/school_list?url=/college/211">211</navigator>
	  <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
	  <navigator url="/page/school_list?url=/college/doubleGood">双一流</navigator>
	  <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
	  <navigator url="/page/choose">筛选</navigator>
	</view>

    <!-- 主要内容区 -->
    <main class="main-content">
      <div class="breadcrumb-area" data-bg-image="/static/assets/images/register-login.png">
        <div class="container h-100 position-relative">
          <div class="row h-100">
            <div class="col-lg-12">
              <div class="breadcrumb-item position-absolute top-50 start-50 translate-middle">
                <text class="breadcrumb-heading" style="font-size: 30px;">高考志愿网</text>
                <div class="d-flex align-items-center">
                  <navigator url="/page/index">首页 <text class="pe-7s-angle-right" ></text></navigator>
                  <text>院校详情</text>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

     <!-- 学院详情 -->
     <div class="single-product-area section-space-top-100">
       <div class="container">
         <div class="row align-items-center">
           <!-- 校徽容器 -->
           <div class="col-lg-6">
             <!-- 校徽内容 -->
             <div class="single-product-img h-100">
               <!-- 在这里添加学校校徽的图片 -->
               <image src="/static/assets/images/universities/nwpu.png" alt="School Logo" style="width: 300px; height: 300px;"></image>
             </div>
           </div>
     
           <!-- 学院信息容器 -->
           <div class="col-lg-6">
             <!-- 学院信息内容 -->
             <div class="product-thumb-with-content row">
               <div class="col-12">
                 <div class="single-product-content" id="college-info">
                   <!-- 在这里添加学校名称、类型、地点、电话和网站等信息 -->
                   <h2>西北工业大学</h2>
                   <p>学校类型：985/211</p>
                   <p>办学地点：中国 西安</p>
                   <p>官方电话：123456789</p>
                   <p>官方网站：<a href="https://www.nwpu.edu.cn/">https://www.nwpu.edu.cn/</a></p>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>

      <!-- 不同部分的选项卡 -->
      <div class="product-tab-area section-space-top-100 section-space-bottom-100">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 d-flex justify-content-center">
              <div class="product-tab-nav d-flex justify-content-center">
                <a class="active btn btn-custom-size" id="description-tab" data-bs-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true">
                  院校简介
                </a>
                <a class="btn btn-custom-size" id="reviews-tab" data-bs-toggle="tab" href="#reviews" role="tab" aria-controls="reviews" aria-selected="false">
                  专业设置
                </a>
                <a class="btn btn-custom-size" id="shipping-tab" data-bs-toggle="tab" href="#shipping" role="tab" aria-controls="shipping" aria-selected="false">
                  历年录取
                </a>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="tab-content product-tab-content">
                <!-- 选项卡内容 -->
                <div class="tab-content product-tab-content">
                  <!-- 选项卡面板 1 -->
                  <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
                    <div class="product-description-body">
                      <p class="short-desc mb-0" id="college-des">
                        <!-- 描述内容 -->
                      </p>
                    </div>
                  </div>
                  <!-- 选项卡面板 2 -->
                  <div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
                    <table class="table-bordered" style="width: 100%;border: black 1px solid" id="major-table">
                      <!-- 专业设置内容 -->
                    </table>
                  </div>
                  <!-- 选项卡面板 3 -->
                  <div class="tab-pane fade" id="shipping" role="tabpanel" aria-labelledby="shipping-tab">
                    <div id="select-bar">
                      <!-- 历年录取内容 -->
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
      </div>
	  </div>
    </main>

    <!-- 底边栏 -->
    <div class="footer-area" style="margin-top: 10px">
      <div class="footer-bottom py-3" :data-bg-color="footerBackgroundColor">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="copyright">
                <span class="copyright-text text-white">Made By NPU</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      loggedIn: false,
      selectOptions: ['大学', '专业'], // 下拉框选项
      selectedOption: '大学', // 默认选择
      searchTerm: '',
      headerBackgroundColor: "#bac34e",
    };
  },
  methods: {
    // 选择下拉框选项
    selectOption(event) {
      this.selectedOption = this.selectOptions[event.detail.value];
      this.searchPlaceholder = this.selectedOption === '大学' ? '输入大学关键字' : '输入专业关键字';
    },
    // 加载历年录取记录
    loadRecords() {
      // 执行加载历年录取记录的逻辑
    },
    // 执行搜索
    search() {
      // 执行搜索逻辑
    }
  }
};
</script>

<style scoped>
/* 组件特定样式 */
/*顶部栏*/
.header-middle {
  display: flex;
  align-items: center;
  justify-content: space-between; /* 使子元素均匀分布 */
  padding: 0 1rem; /* 调整内边距 */
}

.header-right {
  display: flex;
  align-items: center;
  justify-content: flex-end; /* 将内容推到最右侧 */
}

/* 下拉框和搜索框之间的分隔样式 */
.separator {
  width: 30rpx; /* 设置分隔宽度 */
}

.select-option text {
  color: #333; /* 设置文字颜色 */
}

/* 下拉框样式 */
.select-option {
  background-color:skyblue; /* 设置背景色 */
  padding: 8rpx 12rpx; /* 设置内边距 */
  border-radius: 5rpx; /* 设置圆角 */
}

/* 调整搜索框区域的样式，使其占据剩余空间 */
.search-and-select {
  flex-grow: 0; /* 使搜索框区域填充剩余空间 */
  display: flex;
  align-items: center;
}

/* 搜索框样式调整 */
.header-searchbox input {
  padding: 12rpx; /* 增加填充以使搜索框更高 */
  width: 300rpx; /* 增加宽度 */
  border: 1rpx solid #ddd; /* 添加边框样式 */
}

/* 为985、211、双一流导航按钮添加样式 */
.main-menu {
  display: flex;
  justify-content: center; /* 水平居中对齐 */
  align-items: center; /* 垂直居中对齐 */
  height: 40px; /* 设置容器的高度 */
}

/* 添加一个分隔符样式，用于在项目之间创建间距 */
.menu-separator {
  width: 60rpx; /* 设置分隔符的宽度 */
}

/*背景图片*/
.breadcrumb-area {
  width:100%; /* 设置宽度为100%，使其充满父容器 */
  height: 500px; /* 设置高度为300像素，或者你想要的其他大小 */
  background-image: url("/static/assets/images/register-login.png");
  background-size:  auto;
  background-position: center center; /* 将背景图像水平和垂直居中 */
  background-repeat: no-repeat; /* 禁止背景图像重复 */
}

.position-relative {
  position: relative; /* 设置相对定位 */
}

.position-absolute {
  position: absolute; /* 设置绝对定位 */
}

.top-50 {
  top: 50%; /* 将元素的顶部边缘放置在其包含元素的顶部边缘的50%处 */
}

.start-50 {
  start: 50%; /* 将元素的左边缘放置在其包含元素的左边缘的50%处 */
}

.translate-middle {
  transform: translate(460%, 200%); /* 平移元素的中心点到其包含元素的中心点 */
}

/*主要内容*/
.separator {
  width: 30rpx; /* 设置分隔符的宽度 */
}

.select-option text {
  color: #333; /* 设置文字颜色 */
}

.select-option {
  background-color: skyblue; /* 设置背景色 */
  padding: 8rpx 12rpx; /* 设置内边距 */
  border-radius: 5rpx; /* 设置圆角 */
}

.search-and-select {
  flex-grow: 0; /* 使搜索框区域填充剩余空间 */
  display: flex;
  align-items: center;
}

.header-searchbox input {
  padding: 12rpx; /* 增加填充以使搜索框更高 */
  width: 300rpx; /* 增加宽度 */
  border: 1rpx solid #ddd; /* 添加边框样式 */
}


/* 学院详情 */
.single-product-area {
  display: flex;
  justify-content: center; /* 内容居中 */
  align-items: center;
  text-align: center; /* 文字居中 */
  margin-bottom: 50px; /* 底部留出一些间隔 */
}

/* 调整学院信息容器的样式，使其排在校徽容器的右侧 */
.product-thumb-with-content {
  display: flex; /* 使用 Flexbox 布局 */
  align-items: center; /* 垂直居中对齐 */
}

/* 调整校徽容器的样式，使其填充整个容器高度 */
.single-product-img {
  height: 100%; /* 填充整个容器高度 */
}


.product-tab-nav {
  display: flex;
  justify-content: center; /* 确保按钮组水平居中 */
  margin-bottom: 20px; /* 如果需要，调整底部间距 */
}

.btn-custom-size {
  margin: 0 10px; /* 调整按钮之间的间距，保持布局紧凑 */
}

/* 选项卡内容 */
.product-tab-content {
  display: flex;
  flex-direction: column; /* 垂直布局选项卡内容 */
  align-items: center; /* 居中显示 */
}

/*
/* 选项卡面板 */
/* .tab-pane { */
  /* flex: 1; /* 使用 Flexbox 来填充剩余空间 */ 
  /* border-radius: 5px; /* 添加圆角 */ 
  /* box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); /* 添加阴影 */ 
  /* padding: 20px; /* 添加内边距 */ 
  /* margin: 0 10px; /* 添加外边距 */ 
/* } */

/* 如果想要完全去掉边框，可以将 border 设置为 none */
.tab-pane {
  border: none; /* 去除边框 */
}

/* 选项卡标题 */
.btn-custom-size {
  text-align: center; /* 居中显示 */
  padding: 10px 20px; /* 添加内边距 */
  border: 1px solid #ccc; /* 添加边框 */
  border-radius: 5px; /* 添加圆角 */
  margin: 0 10px; /* 添加外边距 */
  cursor: pointer; /* 添加光标样式 */
}

/* 激活状态的选项卡标题样式 */
.btn-custom-size.active {
  background-color: #f0f0f0; /* 设置背景色 */
}
</style>
