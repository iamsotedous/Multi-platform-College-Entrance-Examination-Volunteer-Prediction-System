$(document).ready(function () {
    if (window.location.search.includes("error")) {
        let str = "<p style=\"color: red\">用户名或密码错误</p>\n" +
            "<button type=\"submit\" class=\"btn btn-custom-size lg-size btn-secondary btn-primary-hover rounded-0\">\n" +
            "登录" +
            "</button>"
        $("#error-bar").html(str)
    }
});

function register() {
    let username = $("#register-username").val()
    let password = $("#register-password").val()
    let re_password = $("#register-re-password").val()
    if (username == "") {
        alert("用户名不能为空")
        return;
    }
    if (password.length <= 8) {
        alert("密码强度过低")
        return;
    }
    if (password != re_password) {
        alert("两次密码不一致")
        return;
    }
    $.ajax({
        type: "post",
        url: "/user/register",
        async: true,
        dataType: "json",
        data: {
            "username": username,
            "password": password
        },
        success: function (data) {
            if (data.code == 1) {
                alert("注册成功")
            } else {
                alert(data.message)
            }
        },
        error: function () {
            console.log("error");
        }
    });
}

function login() {
    let username = $("#username").val()
    let password = $("#password").val()
    if (username.length < 1) {
        alert("用户名不能为空")
        return;
    }
    if (password.length < 1) {
        alert("密码不能为空")
        return;
    }
    $.ajax({
        type: "post",
        url: "/login",
        async: true,
        dataType: "json",
        data: {
            "username": username,
            "password": password
        },
        success: function (data) {
            if (data.code == 1) {
                alert("登录成功")
                window.location.href = "/page/index"
            } else {
                alert(data.message)
                return false;
            }
        },
        error: function () {
            console.log("error");
        }
    });
}