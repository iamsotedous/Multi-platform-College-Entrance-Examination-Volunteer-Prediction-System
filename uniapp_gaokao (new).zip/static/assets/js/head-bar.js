$(document).ready(function () {
    $.ajax({
        type: "get",
        url: "/user/info",
        async: true,
        dataType: "json",
        success: function (data) {
            let str = "";
            if (data.code == 1) {
                let username = data.data.username
                str += "<li><a class=\"dropdown-item\" href=\"\">" + username + "</a></a></li>\n" +
                    "   <li><a class=\"dropdown-item\" href=\"/page/favorite_list?url=/user/favorite\">我的收藏</a></li>\n" +
                    "   <li><a class=\"dropdown-item\" href=\"/logout\">登出</a></li>"
            } else {
                str += "<li><a class=\"dropdown-item\" href=\"/page/login_register\">登录|注册</a></li>\n"
            }
            $("#user-bar").html(str)
        },
        error: function () {
            console.log("error");
        }
    });
});

function search() {
    let search_type = document.getElementById("search-type").value
    let name = document.getElementById("search-term").value
    if (name == "") {
        alert("关键字不能为空")
    } else {
        if (search_type == 0) {
            window.location.href = "/page/school_list?url=/college/search/name?name=" + name
        }
        if (search_type == 1) {
            window.location.href = "/page/school_list?url=/major/search/name?name=" + name
        }
    }
}
