$(document).ready(function () {
    $.ajax({
        type: "get",
        url: window.location.search.substring(5),
        async: true,
        dataType: "json",
        success: function (data) {
            let college = data.data
            load_logo(college)
            load_info(college)
            load_des(college)
            load_majors(college)
            load_records()
        },
        error: function () {
            console.log("error");
        }
    });
});

function load_logo(college) {
    $("#college-logo").html("<img style=\"width: 300px;height: 300px\"\n" +
        "src=\"https://static-data.gaokao.cn/upload/logo/" + college.cid + ".jpg\"\n" +
        ">")
}

function load_info(college) {
    str = "<h2 style=\"border-bottom: gray solid 2px;color: #444444;font-size: 40px\">\n" +
        "" + college.name + "</h2>\n" +
        "<div style=\"margin-left: 60px;margin-top: 40px\">\n" +
        "<p>\n" +
        "" + college.type_name + "\n" +
        "</p>\n" +
        "<p>\n" +
        "<i class=\"pe-7s-map-marker\"></i>\n" +
        "办学地点：" + college.city_name + " " + college.county_name + "\n" +
        "</p>\n" +
        "<p>\n" +
        "<i class=\"pe-7s-headphones\"></i>\n" +
        "官方电话:" + college.official_phone + "\n" +
        "</p>\n" +
        "<a href='" + college.official_web + "'>\n" +
        "<i class=\"pe-7s-browser\"></i>\n" +
        "官方网站:" + college.official_web + "\n" +
        "</a>\n" +
        "</div>\n" +
        "<ul class=\"quantity-with-btn\" style=\"margin-top: 50px;margin-left: 60px\">\n" +
        "<li class=\"add-to-cart\">\n" +
        "<a class=\"btn btn-custom-size lg-size btn-primary btn-secondary-hover rounded-0\"\n" +
        "  onclick='add_favorite(" + college.cid + ")'>加入收藏</a>\n" +
        "</li>\n" +
        "</ul>"
    $("#college-info").html(str)
}

function load_des(college) {
    str = college.introduction
    $("#college-des").html(str)
}

function add_favorite(cid) {
    $.ajax({
        type: "post",
        url: "/user/favorite_add",
        async: true,
        dataType: "json",
        data: {
            cid: cid
        },
        success: function (data) {
            alert(data.message)
        },
        error: function () {
            console.log("error");
        }
    });
}

function load_majors(college) {
    $.ajax({
        type: "get",
        url: "/major/college?cid=" + college.cid,
        async: true,
        dataType: "json",
        success: function (data) {
            let majors = data.data
            let str = ""
            str += "<tr style=\"border-bottom: gainsboro 1px solid\">\n" +
                "<th style=\"text-align: center;border: gainsboro 1px solid;width: 33%\">专业名</th>\n" +
                "<th style=\"text-align: center;border: gainsboro 1px solid;width: 33%\">教育部代码</th>\n" +
                "<th style=\"text-align: center;border: gainsboro 1px solid;width: 33%\">学习时长</th>\n" +
                "</tr>"
            for (let i in majors) {
                str += "<tr style=\"border-bottom: gainsboro 1px solid;height: 30px\">\n" +
                    "<td style=\"text-align: center;border:gainsboro 1px solid;width: 33%\">" + majors[i].mname + "</td>\n" +
                    "<td style=\"text-align: center;border:gainsboro 1px solid;width: 33%\">" + majors[i].moe + "</td>\n" +
                    "<td style=\"text-align: center;border:gainsboro 1px solid;width: 33%\">" + majors[i].myear + "</td>\n" +
                    "</tr>"
            }
            $("#major-table").html(str)
        },
        error: function () {
            console.log("error");
        }
    });
}

function load_records() {
    let year = $("#year-select").val()
    let pid = $("#province-select").val()
    $.ajax({
        type: "get",
        url: "/college/records?cid=" + getV("cid") + "&year=" + year + "&pid=" + pid,
        async: true,
        dataType: "json",
        success: function (data) {
            let records = data.data
            let str = ""
            str += "<tr style=\"border-bottom: gainsboro 1px solid\">\n" +
                "<th style=\"text-align: center;border: gainsboro 1px solid\">专业名</th>\n" +
                "<th style=\"text-align: center;border: gainsboro 1px solid\">分数线</th>\n" +
                "<th style=\"text-align: center;border: gainsboro 1px solid\">分数排名</th>\n" +
                "<th style=\"text-align: center;border: gainsboro 1px solid\">批次</th>\n" +
                "<th style=\"text-align: center;border: gainsboro 1px solid\">分类</th>\n" +
                "<th style=\"text-align: center;border: gainsboro 1px solid\">要求</th>\n" +
                "</tr>"
            for (let i in records) {
                str += "<tr style=\"border-bottom: gainsboro 1px solid\">\n" +
                    "<td style=\"text-align: center;border: gainsboro 1px solid\">"+records[i].rname+"</td>\n" +
                    "<td style=\"text-align: center;border: gainsboro 1px solid\">"+records[i].rscore+"</td>\n" +
                    "<td style=\"text-align: center;border: gainsboro 1px solid\">"+records[i].rrank+"</td>\n" +
                    "<td style=\"text-align: center;border: gainsboro 1px solid\">"+records[i].rbatch+"</td>\n" +
                    "<td style=\"text-align: center;border: gainsboro 1px solid\">"+records[i].rtype+"</td>\n" +
                    "<td style=\"text-align: center;border: gainsboro 1px solid\">"+records[i].mrequire+"</td>\n" +
                    "</tr>"
            }
            $("#record-table").html(str)
        },
        error: function () {
            console.log("error");
        }
    });
}

function getV(variable) {
    let result = window.location.search.substring(5);
    if (variable != null) {
        result = getQueryVariable(result, variable)
    }
    return result;
}

function getQueryVariable(str, variable) {
    if (str.split("?").length == 1) {
        return null
    }
    var query = str.split("?")[1]
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
            return decodeURI(pair[1]);
        }
    }
    return null;
}