<template>
  <div class="main-wrapper">
    <!-- 顶部栏 -->
    <view class="main-header_area">
      <view class="header-middle container d-flex align-items-center justify-content-between py-2">
        <!-- logo -->
        <navigator url="/page/index" class="header-logo mr-3">
          <image src="/static/assets/images/logo/logo.png" alt="Header Logo" style="width: 200rpx; height: 80rpx;"></image>
        </navigator>
        <!-- 大学选择框和搜索框在同一行 -->
        <view class="search-and-select d-flex align-items-center flex-grow-1">
          <!-- 下拉框 -->
          <picker mode="selector" range="{1}" @change="selectOption" class="mr-2">
            <view class="nice-select select-option">
              <text>{{ selectedOption }}</text>
            </view>
          </picker>
          <view class="separator"></view> <!-- 添加分隔 -->
          <!-- 搜索框 -->
          <form class="header-searchbox d-flex align-items-center" @submit.stop>
            <input v-model="searchTerm" class="input-field" type="text" :placeholder="searchPlaceholder" />
            <button class="search-button" type="button" @click="search">
              <i class="pe-7s-search"></i>
            </button>
          </form>
        </view>
        <!-- 用户菜单入口 -->
        <view class="header-right">
          <button v-if="loggedIn" class="user-menu" type="button" id="accountButton">
            <text>本人账号</text>
          </button>
          <button v-if="loggedIn" class="user-menu" type="button" id="favoritesButton">
            <text>我的收藏</text>
          </button>
          <button v-if="loggedIn" class="user-menu" type="button" id="logoutButton" @click="logout">
            <text>退出</text>
          </button>
          <button v-if="!loggedIn" class="user-menu" type="button" id="loginButton" @click="showLoginRegisterPage">
            <text>登陆/注册</text>
          </button>
        </view>
      </view>
    </view>
    <!-- 功能栏 -->
    <view class="main-menu d-flex justify-content-center align-items-center bg-light py-1" style="background-color: cadetblue;">
      <navigator url="/page/school_list?url=/college/985">985</navigator>
      <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
      <navigator url="/page/school_list?url=/college/211">211</navigator>
      <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
      <navigator url="/page/school_list?url=/college/doubleGood">双一流</navigator>
      <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
      <navigator url="/page/choose">筛选</navigator>
    </view>

    <!-- 选择区域 -->
        <div class="choose-area section-space-top-100 d-flex justify-content-center">
          <div class="container">
            <div class="choose-content">
              <h2 class="sub-title mb-4">选择对应选项，填写排名</h2>
              <form class="choose-form">
                <div class="form-row">
                  <select id="province-select" class="form-control" v-model="selectedProvince" @change="provinceChange">
                      <option v-for="province in provinces" :value="province">{{ province }}</option>
                    </select>
                    <select id="batch-select" class="form-control" v-model="selectedBatch" @change="batchChange">
                      <option v-for="batch in batches" :value="batch">{{ batch }}</option>
                    </select>
                    <select id="require-select" class="form-control" v-model="selectedRequire">
                      <option v-for="require in requires" :value="require">{{ require }}</option>
                    </select>
                  <input id="search-rank" class="form-control" type="text" placeholder="输入排名" v-model="rank">
                  <button class="btn btn-custom-size btn-primary rounded-0" @click.prevent="choose">筛选</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
	  <div class="main-footer d-flex justify-content-center align-items-center bg-light py-1" style="background-color: cadetblue;">
      <div class="footer-content">Made By NPU</div>
    </div>
    </template>

<script>
export default {
  data() {
    return {
      rank: '',
      loggedIn: false,
      selectOptions: ['大学', '专业'],
      selectedOption: '大学',
      searchTerm: '',
      provinces: [
        '北京', '天津', '上海', '重庆',
        '河北', '山西', '辽宁', '吉林', '黑龙江',
        '江苏', '浙江', '安徽', '福建', '江西', '山东',
        '河南', '湖北', '湖南', '广东', '海南', '四川',
        '贵州', '云南', '陕西', '甘肃', '青海', '台湾',
        '内蒙古', '广西', '西藏', '宁夏', '新疆',
        '香港', '澳门'
      ],
      batches: ['新高考物理', '新高考历史', '综合（旧高考）'],
      requires: ['文科', '理科', '化学生物', '化学地理', '化学政治', '地理政治', '生物政治', '地理生物'],
      selectedProvince: '',
      selectedBatch: '',
      selectedRequire: '',
    };
  },
  methods: {
    selectOption(event) {
      this.selectedOption = this.selectOptions[event.detail.value];
      this.searchPlaceholder = this.selectedOption === '大学' ? '输入大学关键字' : '输入专业关键字';
    },
    provinceChange() {
      // 处理省份变化的逻辑
    },
    batchChange() {
      // 处理批次变化的逻辑
    },
    choose() {
      // 执行筛选逻辑
      console.log('筛选条件：', this.rank);
      // 在这里添加API调用或相关逻辑
    },
  },
}
</script>


<style scoped>
/* 在这里添加样式 */
/* 将顶部栏设置为flex布局 */
.header-middle {
  display: flex;
  align-items: center;
  justify-content: space-between; /* 使子元素均匀分布 */
  padding: 0 1rem; /* 调整内边距 */
}

.header-right {
  display: flex;
  align-items: center;
  justify-content: flex-end; /* 将内容推到最右侧 */
}

/* 下拉框和搜索框之间的分隔样式 */
.separator {
  width: 30rpx; /* 设置分隔宽度 */
}

.select-option text {
  color: #333; /* 设置文字颜色 */
}

/* 下拉框样式 */
.select-option {
  background-color:skyblue; /* 设置背景色 */
  padding: 8rpx 12rpx; /* 设置内边距 */
  border-radius: 5rpx; /* 设置圆角 */
}

/* 调整搜索框区域的样式，使其占据剩余空间 */
.search-and-select {
  flex-grow: 0; /* 使搜索框区域填充剩余空间 */
  display: flex;
  align-items: center;
}

/* 搜索框样式调整 */
.header-searchbox input {
  padding: 12rpx; /* 增加填充以使搜索框更高 */
  width: 300rpx; /* 增加宽度 */
  border: 1rpx solid #ddd; /* 添加边框样式 */
}

/* 为985、211、双一流导航按钮添加样式 */
.main-menu {
  display: flex;
  justify-content: center; /* 水平居中对齐 */
  align-items: center; /* 垂直居中对齐 */
  height: 40px; /* 设置容器的高度 */
}

/* 添加一个分隔符样式，用于在项目之间创建间距 */
.menu-separator {
  width: 60rpx; /* 设置分隔符的宽度 */
}

.choose-area {
  text-align: center; /* 将内容居中显示 */
}

.choose-content {
  max-width: 800rpx; /* 设置最大宽度 */
  margin: 0 auto; /* 居中显示 */
}

.col-lg-2 {
  flex: 1; /* 设置每个选择框的大小相等 */
}



/* 移除可能影响居中的顶部栏的内边距 */
.main-header_area {
  width: 100%; /* 或者你可能需要根据实际情况进行调整 */
  /* 为顶部栏添加其他所需的样式 */
}

.choose-area {
  width: 100%;
  display: flex;
  justify-content: center; /* 水平居中 */
  align-items: center; /* 垂直居中 */
  padding: 20px 0; /* 适当的上下内边距 */
  position: relative; /* 使用相对定位 */
  top: 250px; /* 向下偏移 20 像素 */
  left: -20px; /* 向左偏移 10 像素 */
  transform: translateY(-50%); /* 使用负的50%偏移来使容器垂直居中 */
}

.choose-content {
  max-width: 1000px; /* 设置最大宽度 */
  width: 100%; /* 宽度占满父容器 */
  padding: 30px; /* 适当的内边距 */
  border-radius: 8px; /* 圆角 */
  background: white; /* 背景颜色 */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* 阴影 */
  text-align: center; /* 文本居中 */
}
/* 表单样式 */
.choose-form .form-row {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
}

/* 控件样式 */
.choose-form .form-control,
#search-rank {
  width: 100%; /* 控件宽度与选择框相同 */
  height: 40px; /* 控件高度与选择框相同 */
  margin: 10px 0; /* 控件间隙 */
  padding: 10px; /* 控件内边距 */
  border: 1px solid #ccc;
  border-radius: 4px;
}


/* 按钮样式 */
.choose-form button {
  width: auto; /* 自动宽度 */
  padding: 5px 50px;
  margin-top: 20px; /* 与控件分开 */
  border: none;
  border-radius: 4px;
  background-color: #007bff;
  color: white;
  cursor: pointer;
}

/* 添加媒体查询以处理不同的屏幕尺寸 */
@media (max-width: 768px) {
  /* 在小屏幕上，可能需要调整内边距和间隙 */
  .choose-content {
    padding: 20px;
    margin: 10px;
  }
}

/* 底部栏容器样式 */
.main-footer {
  position: fixed; /* 使用固定定位 */
  bottom: 0; /* 与底部对齐 */
  width: 100%; /* 宽度占满整个屏幕 */
  height: 40px; /* 设置容器的高度 */
  background-color: cadetblue; /* 背景颜色 */
  display: flex;
  justify-content: center;
  align-items: center;
}

/* 底部栏文本样式 */
.footer-content {
  color: black; /* 文本颜色 */
  font-size: 20px; /* 文本大小 */
  text-align: center;
}
</style>
