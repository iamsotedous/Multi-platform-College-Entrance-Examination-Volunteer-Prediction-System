<template>
  <view>
    <view id="login_header">
      <navigator url="../../index.html">
        <image class="logo_img" :src="baseUrl + '/static/assets/images/logo/logo.png'" mode="aspectFit" style="width: 200px; height: 75px;" />
      </navigator>
    </view>
	
    <view class="login_banner">
		<view id="l_content">
			<span class="login_word">欢迎登录</span>
		</view>
      <view class="login_form">
        <view class="login_box">
          <view class="tit">
            <text>高考志愿填报</text>
          </view>
          <view class="msg_cont">
            <block></block>
            <text class="errorMessage">{{ loginError }}</text>
          </view>
          <view class="form">
            <form @submit="checklogin">
              <view class="form-row">
                <text>用户名称：</text>
                <input class="itxt" type="text" placeholder="请输入用户名" autocomplete="off" tabindex="1" name="username" v-model="uname" />
              </view>
              <view class="form-row">
                <text>用户密码：</text>
                <input class="itxt" type="password" placeholder="请输入密码" autocomplete="off" tabindex="1" name="password" v-model="upass" />
              </view>
              <input type="submit" value="登录" id="sub_btn" />
            </form>
            <view class="tit">
              <navigator url="register">立即注册</navigator>
            </view>
          </view>
        </view>
      </view>
    </view>
    <view class="bottom">
      <text>
        <navigator url="../../index.html">高考志愿网.Copyright ©2024</navigator>
      </text>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      baseUrl: '', // 你的基本URL
      uname: '', // 用户名
      upass: '', // 密码
      loginError: '' // 登录错误信息
    };
  },
  methods: {
    checklogin(ev) {
      if (this.uname === '') {
        this.loginError = '用户名不能为空';
        ev.preventDefault();
        return;
      }
      if (this.upass === '') {
        this.loginError = '用户密码不能为空';
        ev.preventDefault();
        return;
      }
    }
  }
};
</script>

<style scoped>
/* 登录页面CSS样式 */

#login_header {
  height: 82px;
  width: 1200px;
}

.login_banner {
  height: 475px;
  background-color: rgb(0,84,163);
}

.login_form {
  height: 310px;
  width: 406px;
  float: right;
  margin-right: 50px;
  margin-top: 50px;
  background-color: #fff;
}

#content {
  height: 475px;
  width: 1200px;
}

.login_box {
  margin: 20px;
  height: 260px;
  /* width: 366px; */
}

.tit {
  display: flex; /* 使用 flex 布局 */
  align-items: center; /* 垂直居中对齐 */
  justify-content: center; /* 水平居中对齐 */
}

.tit text {
  font-size: 22px; /* 设置字体大小 */
  font-weight: bold; /* 设置字体加粗 */
  color: rgb(0,84,163); /* 设置字体颜色 */
  
}

h1 {
  font-size: 20px;
}
.msg_cont {
  background: none repeat scroll 0 0 #fff6d2;
  border: 1px solid #ffe57d;
  color: #666;
  height: 18px;
  line-height: 18px;
  padding: 3px 10px 3px 40px;
  position: relative;
  border: none;
}

.msg_cont b {
  background: url('../img/pwd-icons-new.png') no-repeat scroll -104px -22px
  rgba(0, 0, 0, 0);
  display: block;
  height: 17px;
  left: 10px;
  margin-top: -8px;
  overflow: hidden;
  position: absolute;
  top: 50%;
  width: 16px;
}

.form .form-row {
  margin-bottom: 10px; /* 调整行之间的间距 */
  display: flex; /* 使用 flex 布局 */
  align-items: center; /* 垂直居中对齐 */
}

.form .form-row text {
  /* margin-right: 10px; */ /* 如果需要添加间距，可以取消注释这行 */
  width: 80px; /* 调整文本部分的宽度 */
}

.form .itxt {
  /* width: 100px; */
  border: 0 none;
  /* float: none; */ /* 不再需要浮动 */
  font-family: '宋体';
  font-size: 15px;
  height: 18px;
  line-height: 18px;
  overflow: hidden;
  padding: 10px 0 10px 10px;
  width: 250px;
  /* margin-left: 80px; */ /* 不再需要这行 */
  border: 1px #e3e3e3 solid;
}


.inp {
  margin-left: 15px;
}

#sub_btn {
  background-color: rgb(0,84,163);
  border: none;
  color: #fff;
  width: 360px;
  height: 40px;
  text-align: center;
  /* margin: auto; */ /* Center horizontally */
  display: block; /* Ensures the margin: auto works */
}

#l_content {
  float: left;
  margin-top: 150px;
  margin-left: 300px;
}

#l_content span {
  font-size: 60px;
  color: white;
}

.tit h1 {
  width: 100%;
  text-align: center;
  float: left;
  /* margin-top: 5px; */
  font-size: 24px;
  margin-bottom: 10px;
  color: rgb(0,84,163);
}

.tit a {
  float: right;
  margin-left: 10px;
  margin-top: 10px;
  color: red;
  text-decoration: none;
}

.tit .errorMsg {
  float: right;
  margin-left: 10px;
  margin-top: 10px;
  color: red;
}

.tit {
  height: 30px;
/*  display: flex;
  align-items: center; /* Vertical centering */
  /*justify-content: center; /* Horizontal centering */ 
}

.tit a {
  color: rgb(0,84,163);
}

.bottom {
  text-align: center; /* 文本居中 */
  margin-top: 20px; /* 可以根据需要调整底部距离 */
}

</style>

