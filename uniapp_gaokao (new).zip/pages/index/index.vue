<template>
  <view class="main-wrapper">
    <!-- 顶部栏 -->
    <view class="main-header_area">
      <view class="header-middle container d-flex align-items-center justify-content-between py-2">
        <!-- logo -->
        <navigator url="/page/index" class="header-logo mr-3">
          <image src="/static/assets/images/logo/logo.png" alt="Header Logo" style="width: 200rpx; height: 80rpx;"></image>
        </navigator>
        <!-- 大学选择框和搜索框在同一行 -->
        <view class="search-and-select d-flex align-items-center flex-grow-1">
          <!-- 下拉框 -->
          <picker mode="selector" range="{1}" @change="selectOption" class="mr-2">
            <view class="nice-select select-option">
              <text>{{ selectedOption }}</text>
            </view>
          </picker>
		  <view class="separator"></view> <!-- 添加分隔 -->
          <!-- 搜索框 -->
          <form class="header-searchbox d-flex align-items-center" @submit.stop>
            <input v-model="searchTerm" class="input-field" type="text" :placeholder="searchPlaceholder" />
            <button class="search-button" type="button" @click="search">
              <i class="pe-7s-search"></i>
            </button>
          </form>
        </view>
        <!-- 用户菜单入口 -->
        <view class="header-right">
          <button v-if="loggedIn" class="user-menu" type="button" id="accountButton">
            <text>本人账号</text>
          </button>
          <button v-if="loggedIn" class="user-menu" type="button" id="favoritesButton">
            <text>我的收藏</text>
          </button>
          <button v-if="loggedIn" class="user-menu" type="button" id="logoutButton" @click="logout">
            <text>退出</text>
          </button>
          <button v-if="!loggedIn" class="user-menu" type="button" id="loginButton" @click="showLoginRegisterPage">
            <text>登陆/注册</text>
          </button>
        </view>
      </view>
    </view>
    <!-- 功能栏 -->
    <view class="main-menu d-flex justify-content-center align-items-center bg-light py-1" style="background-color: cadetblue;">
      <navigator url="/page/school_list?url=/college/985">985</navigator>
      <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
      <navigator url="/page/school_list?url=/college/211">211</navigator>
      <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
      <navigator url="/page/school_list?url=/college/doubleGood">双一流</navigator>
      <view class="menu-separator"></view> <!-- 添加一个分隔符 -->
      <navigator url="/page/choose">筛选</navigator>
    </view>
    <!-- 滑动展示栏 -->
    <view class="slider-area">
        <swiper class="main-slider swiper-arrow with-bg_white" :style="{ backgroundColor: sliderBackgroundColor }" indicator-dots="{{ true }}" autoplay="{{ true }}" interval="{{ 5000 }}" duration="{{ 500 }}" style="height: 600rpx;" >
            <swiper-item v-for="(slide, index) in slides" :key="index" class="swiper-slide animation-style-01">
              <navigator :url="slide.link">
                <div class="image-container"> <!-- 添加一个容器用于居中图片 -->
                  <image :src="slide.image" class="slider-image"></image>
                </div>
              </navigator>
            </swiper-item>
            <swiper-navigation class="swiper-button-next"></swiper-navigation>
            <swiper-navigation class="swiper-button-prev"></swiper-navigation>
        </swiper>
      </view>
    <!-- 院校陈列 -->
    <view class="product-area section-space-top-100">
      <view class="container">
        <view class="row">
          <view class="col-lg-12">
            <view class="product-topbar">
              <ul>
                <li style="width: 100%;text-align: center">
                  院校展示
                </li>
              </ul>
            </view>
            <view class="tab-content" id="myTabContent">
              <view class="tab-pane fade show active" id="all-items" role="tabpanel" aria-labelledby="all-items-tab">
                <view class="product-item-wrap row">
                  <view class="col-xl-3 col-lg-4 col-sm-6" v-for="(college, index) in colleges" :key="index">
                    <view class="product-item">
                      <view class="product-img" style="border: 2px solid #f1f1f1;text-align: center">
                        <navigator :url="college.link">
                          <image style="width: 200px;height: 200px" :src="college.image" alt="Product Images"></image>
                        </navigator>
                      </view>
                      <view class="product-content">
                        <navigator :url="college.link">
                          <text class="product-name">{{ college.name }}</text>
                        </navigator>
                      </view>
                    </view>
                  </view>
                </view>
              </view>
            </view>
          </view>
        </view>
      </view>
    </view>
    <!-- 底边栏 -->
    <view class="footer-area">
      <view class="footer-bottom py-3">
        <view class="container text-center">
          <text class="copyright-text text-white">Made By NPU</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      loggedIn: false,
      selectOptions: ['大学', '专业'], // 下拉框选项
      selectedOption: '大学', // 默认选择
      searchTerm: '',
	  
	  sliderBackgroundColor: '#ffffff', // 设置滑动展示栏的背景色
      slides: [
        {
          title: '西北工业大学',
          link: 'https://www.nwpu.edu.cn/',
          image: 'https://xgdst.nwpu.edu.cn/images/22/12/13/6z5ywbpljc/10%E6%9C%88.jpg'
        },
        {
          title: '清华大学',
          link: 'https://www.tsinghua.edu.cn/',
          image: 'https://www.tsinghua.edu.cn/__local/8/D3/34/464269BEDDBDCE7FE229998697D_A96F2368_BF34C.png'
        }
      ],
	  
      colleges: [
        {
          name: '清华大学',
          link: '/page/college_info?url=/college/info?cid=140',
          image: 'https://static-data.gaokao.cn/upload/logo/140.jpg'
        },
        {
          name: '北京大学',
          link: '/page/college_info?url=/college/info?cid=31',
          image: 'https://static-data.gaokao.cn/upload/logo/31.jpg'
        },
        {
          name: '浙江大学',
          link: '/page/college_info?url=/college/info?cid=114',
          image: 'https://static-data.gaokao.cn/upload/logo/114.jpg'
        },
        {
          name: '上海交通大学',
          link: '/page/college_info?url=/college/info?cid=125',
          image: 'https://static-data.gaokao.cn/upload/logo/125.jpg'
        },
        {
          name: '复旦大学',
          link: '/page/college_info?url=/college/info?cid=132',
          image: 'https://static-data.gaokao.cn/upload/logo/132.jpg'
        },
        {
          name: '南京大学',
          link: '/page/college_info?url=/college/info?cid=111',
          image: 'https://static-data.gaokao.cn/upload/logo/111.jpg'
        },
        {
          name: '中国科学技术大学',
          link: '/page/college_info?url=/college/info?cid=66',
          image: 'https://static-data.gaokao.cn/upload/logo/66.jpg'
        },
        {
          name: '华中科技大学',
          link: '/page/college_info?url=/college/info?cid=127',
          image: 'https://static-data.gaokao.cn/upload/logo/127.jpg'
        }
      ]
    };
  },
  methods: {
	
	showLoginRegisterPage() {
	      // 跳转到登录/注册页面
	      uni.navigateTo({
	        url: '/pages/register/register.vue'
	      });
	    },
	
    selectOption(event) {
      this.selectedOption = this.selectOptions[event.detail.value];
      this.searchPlaceholder = this.selectedOption === '大学' ? '输入大学关键字' : '输入专业关键字';
    },
    search() {
      // 实现搜索功能的方法
    },
    goToUniversity(link) {
      // 根据链接跳转到相应页面
      uni.navigateTo({
        url: link
      });
    }
  }
};
</script>

<style scoped>
/* 在这里添加您的样式 */

/* 将顶部栏设置为flex布局 */
.header-middle {
  display: flex;
  align-items: center;
  justify-content: space-between; /* 使子元素均匀分布 */
  padding: 0 1rem; /* 调整内边距 */
}

.header-right {
  display: flex;
  align-items: center;
  justify-content: flex-end; /* 将内容推到最右侧 */
}

/* 下拉框和搜索框之间的分隔样式 */
.separator {
  width: 30rpx; /* 设置分隔宽度 */
}

.select-option text {
  color: #333; /* 设置文字颜色 */
}

/* 下拉框样式 */
.select-option {
  background-color:skyblue; /* 设置背景色 */
  padding: 8rpx 12rpx; /* 设置内边距 */
  border-radius: 5rpx; /* 设置圆角 */
}

/* 调整搜索框区域的样式，使其占据剩余空间 */
.search-and-select {
  flex-grow: 0; /* 使搜索框区域填充剩余空间 */
  display: flex;
  align-items: center;
}

/* 搜索框样式调整 */
.header-searchbox input {
  padding: 12rpx; /* 增加填充以使搜索框更高 */
  width: 300rpx; /* 增加宽度 */
  border: 1rpx solid #ddd; /* 添加边框样式 */
}

/* 为985、211、双一流导航按钮添加样式 */
.main-menu {
  display: flex;
  justify-content: center; /* 水平居中对齐 */
  align-items: center; /* 垂直居中对齐 */
  height: 40px; /* 设置容器的高度 */
}

/* 添加一个分隔符样式，用于在项目之间创建间距 */
.menu-separator {
  width: 60rpx; /* 设置分隔符的宽度 */
}

/*滑动栏*/
.image-container {
  display: flex;
  justify-content: center; /* 水平居中 */
  align-items: center; /* 垂直居中 */
  width: 100%; /* 容器宽度与滑动项宽度相同 */
  height: 100%; /* 容器高度与滑动项高度相同 */
}

.slider-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain; /* 控制图片填充方式，保持宽高比 */
}

.swiper-slide {
  width: 500rpx; /* 设置滑动项的宽度 */
  height: 500rpx; /* 设置滑动项的高度 */
}

.main-slider {
  background-color: #ffffff; /* 设置滑动展示栏的背景色 */
}


/* 院校陈列部分样式 */
.product-area {
  margin-top: 100rpx; /* 添加上间距 */
  margin-bottom: 20rpx; /* 添加下间距 */
  padding-left: 400rpx; /* 添加左内边距 */
  padding-right: 400rpx; /* 添加右内边距 */
}

.slider-area {
  margin-bottom: 100rpx; /* 添加下间距 */
}

.product-item .product-img {
  width: auto; /* 调整图片宽度 */
  height: 200px; /* 设置固定高度 */
  line-height: 200px; /* 居中对齐图片 */
  border: none; /* 移除边框 */
}

.product-item .product-content {
  text-align: center; /* 文本居中 */
}

.product-item {
  margin-bottom: 20px; /* 调整院校项之间的间距 */
}

.product-item-wrap {
  display: flex;
  flex-wrap: wrap; /* 允许院校项自动换行 */
  justify-content: space-around; /* 横向居中对齐 */
}

.col-xl-3 {
  flex: 0 0 25%; /* 每行四个院校，每个占据四分之一的宽度 */
}


/*底边栏*/
.footer-area {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
}

.footer-bottom {
  background-color: #ffffff; /* 设置底部背景色 */
  /*border-top: 2px solid blue; /* 添加蓝色边框 */
}

.footer-bottom .container {
  padding: 0; /* 移除容器内边距 */
  text-align: center; /* 水平居中文本 */
}

.footer-bottom .copyright-text {
  color: black; /* 设置文字颜色为白色 */
  display: inline-block; /* 将文本包装成块级元素 */
  margin: 0 auto; /* 设置左右外边距为自动以实现水平居中 */
}


</style>
